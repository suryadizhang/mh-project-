"""
Admin API Endpoints
Authenticated endpoints for admin operations
"""
