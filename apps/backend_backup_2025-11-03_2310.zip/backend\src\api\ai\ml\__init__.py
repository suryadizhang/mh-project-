"""
Machine Learning & Self-Learning Module

This module contains all AI training, fine-tuning, and continuous learning components:
- PII scrubbing and data safety
- Training dataset builders
- Fine-tuning automation
- Model evaluation and A/B testing
- Feedback collection and processing
- Performance analytics

Author: MyHibachi Development Team
Created: October 31, 2025
Version: 2.0.0 (Self-Learning Edition)
"""

from .feedback_processor import FeedbackProcessor, get_feedback_processor
from .model_deployment import ModelDeployment, get_deployment_manager
from .model_fine_tuner import ModelFineTuner, get_fine_tuner
from .pii_scrubber import PIIScrubber, get_pii_scrubber
from .training_dataset_builder import (
    TrainingDatasetBuilder,
    get_dataset_builder,
)

__all__ = [
    # Feedback
    "FeedbackProcessor",
    # Deployment
    "ModelDeployment",
    # Fine-Tuning
    "ModelFineTuner",
    # PII Safety
    "PIIScrubber",
    # Training Pipeline
    "TrainingDatasetBuilder",
    "get_dataset_builder",
    "get_deployment_manager",
    "get_feedback_processor",
    "get_fine_tuner",
    "get_pii_scrubber",
]
