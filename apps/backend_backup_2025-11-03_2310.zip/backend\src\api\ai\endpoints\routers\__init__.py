"""
Router package initialization
"""
