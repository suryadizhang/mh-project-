"""Initial AI Router schema with conversations, messages, knowledge base, and agents

Revision ID: 56d701cf2472
Revises:
Create Date: 2025-09-21 14:37:27.689088

"""

# revision identifiers, used by Alembic.
revision = "56d701cf2472"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
