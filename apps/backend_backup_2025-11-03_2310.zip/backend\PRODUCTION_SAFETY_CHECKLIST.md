# Production Safety Checklist for OpenAPI/Swagger Fix

## Summary of Changes Made

### 1. **Pydantic Field Defaults (CRITICAL FIX)**
**Issue**: Using `default={}` or `default=[]` creates shared mutable objects across instances.
**Fix**: Changed to `default_factory=dict` and `default_factory=list`.
**Production Impact**: ✅ SAFE - Prevents data leakage between requests.

**Files Changed**:
- `api/app/schemas/health.py` - 5 fields
- `api/app/schemas/social.py` - 1 field  
- `api/ai/endpoints/schemas.py` - 7 fields
- `api/ai/endpoints/routers/chat.py` - 1 field
- `api/ai/endpoints/routers/admin.py` - 1 field
- `api/app/cqrs/base.py` - 1 field

**Test**: Ensure multiple concurrent requests don't share data in dict/list fields.

---

### 2. **Dependency Injection Pattern Fixes**
**Issue**: Functions returning `Depends(...)` caused nested Depends and CallableSchema errors.
**Fix**: Converted factory functions to direct dependency callables.

**Files Changed**:
- `api/deps_enhanced.py`:
  - `get_di_container()` - Now returns container directly (not Depends wrapper)
  - `get_booking_repository()` - Uses `Depends(get_di_container)` in param
  - `get_customer_repository()` - Uses `Depends(get_di_container)` in param
  - `get_database_session()` - Uses `Depends(get_di_container)` in param
  - `get_authenticated_booking_service()` - Now async callable
  - `get_admin_booking_service()` - Now async callable
  - `get_authenticated_customer_service()` - Now async callable
  - `get_admin_customer_service()` - Now async callable
  - `get_admin_booking_context()` - Now async callable
  - `get_customer_service_context()` - Now async callable

**Production Impact**: ✅ SAFE - Dependencies still resolve correctly, just cleaner pattern.

**Test**: 
```python
# Verify dependencies inject correctly
from api.deps_enhanced import get_di_container, get_booking_repository
from fastapi import Depends

@app.get("/test-deps")
async def test_deps(
    container = Depends(get_di_container),
    booking_repo = Depends(get_booking_repository)
):
    assert container is not None
    assert booking_repo is not None
    return {"status": "ok"}
```

---

### 3. **Station Admin Permission System**
**Issue**: `require_station_permission()` returned a decorator (callable), causing CallableSchema error.
**Fix**: Converted to return FastAPI dependency function.

**Files Changed**:
- `api/app/auth/station_middleware.py`:
  - `require_station_permission(permission)` - Now returns dependency function
  - `require_station_role(role)` - Now returns dependency function  
  - `require_station_access()` - Now returns dependency function
  - `audit_log_action()` - Signature uses `AuthenticatedUser` param

- `api/app/routers/station_admin.py`:
  - All audit_log_action calls updated to new signature
  - Uses `AsyncSession` instead of sync `Session`
  - Uses `get_db_session` from database.py

**Production Impact**: ⚠️ REQUIRES TESTING
- **CRITICAL**: Permission enforcement must still work correctly
- **CRITICAL**: Audit logging must capture all actions
- **Database**: Async session usage must work with existing queries

**Test**:
```python
# Test permission enforcement
async def test_station_permissions():
    # User without permission should get 403
    # User with permission should access endpoint
    
# Test audit logging  
async def test_audit_logging():
    # Verify station_activity_logs table gets entries
    # Check user_id, station_id, action captured
    
# Test async session
async def test_async_queries():
    # Verify all CRUD operations work with AsyncSession
```

---

### 4. **Outbox Worker Pattern**
**Issue**: 
- Using generator `get_db_session()` as async context manager
- Querying non-existent OutboxEntry columns
- JSON extraction not SQLite-compatible

**Fix**:
- Use `get_db_context()` async context manager
- Query correct OutboxEntry fields (status, attempts, next_attempt_at, completed_at, last_error)
- Filter by payload.event_type in Python (not SQL JSON extraction)

**Files Changed**:
- `api/app/workers/outbox_processors.py`:
  - `_process_batch()` - Uses `get_db_context()`
  - `_get_pending_events()` - Filters in Python, not SQL
  - `_mark_event_processed()` - Uses `completed_at` field
  - `_handle_event_error()` - Uses `attempts`, `last_error`, `next_attempt_at`

**Production Impact**: ⚠️ REQUIRES TESTING
- **Worker startup**: Disabled by default in config (workers_enabled=False)
- **Event processing**: Must test with real Stripe/SMS/Email events
- **Retry logic**: Exponential backoff must work correctly

**Test**:
```python
# Test worker processes outbox entries
async def test_outbox_worker():
    # Create test OutboxEntry with event_type in payload
    # Verify worker picks it up and processes
    # Check retry logic on failure
    # Verify completed_at set on success
```

---

### 5. **Configuration Changes**
**Issue**: Workers starting on app init causing DB/model errors during OpenAPI generation.
**Fix**: Disabled workers by default (`workers_enabled=False`).

**Files Changed**:
- `api/app/config.py`:
  - `workers_enabled: bool = False`
  - `sms_worker_enabled: bool = False`
  - `email_worker_enabled: bool = False`
  - `stripe_worker_enabled: bool = False`

**Production Impact**: ⚠️ MUST ENABLE IN PRODUCTION
Set environment variables in production:
```bash
export WORKERS_ENABLED=true
export SMS_WORKER_ENABLED=true
export EMAIL_WORKER_ENABLED=true
export STRIPE_WORKER_ENABLED=true
```

---

### 6. **Rate Limiting Fix**
**Issue**: Nested `Depends(RateLimitTier.ai())` - RateLimitTier.ai() already returns Depends.
**Fix**: Removed outer Depends wrapper.

**Files Changed**:
- `api/v1/endpoints/ai/chat.py`: Changed `dependencies=[Depends(RateLimitTier.ai())]` to `dependencies=[RateLimitTier.ai()]`

**Production Impact**: ✅ SAFE - Rate limiting still applies correctly.

---

## Production Deployment Steps

### 1. Pre-Deployment Testing
```bash
# Run with SQLite (local test)
cd apps/backend/src
export DATABASE_URL="sqlite+aiosqlite:///./test_myhibachi.db"
python -m uvicorn api.app.main:app --port 8000

# Test OpenAPI generation
curl http://localhost:8000/openapi.json | jq '.paths | length'
# Should return > 0 endpoints

# Test Swagger UI
# Open http://localhost:8000/docs
# Verify all endpoints load
```

### 2. Enable Workers in Production
In production `.env` or environment:
```bash
WORKERS_ENABLED=true
SMS_WORKER_ENABLED=true
EMAIL_WORKER_ENABLED=true
STRIPE_WORKER_ENABLED=true

# Also ensure worker configs are set
RINGCENTRAL_ENABLED=true
RINGCENTRAL_CLIENT_ID=...
RINGCENTRAL_CLIENT_SECRET=...
# etc.
```

### 3. Database Migration Check
```bash
# Verify OutboxEntry model matches actual table
# Check columns exist: status, attempts, next_attempt_at, completed_at, last_error, payload (JSON)

# If using events.outbox_entries table:
SELECT column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'outbox_entries' 
AND table_schema = 'events';
```

### 4. Monitor After Deployment

#### A. Check OpenAPI/Swagger
```bash
# Verify OpenAPI schema generates
curl https://api.myhibachi.com/openapi.json | jq '.paths | length'

# Check Swagger UI loads
# https://api.myhibachi.com/docs
```

#### B. Test Permission System
```bash
# Try accessing station admin endpoints
# Verify permission enforcement works
# Check audit logs are created
```

#### C. Monitor Workers
```bash
# Check worker logs
tail -f /var/log/myhibachi/workers.log

# Verify events are processed
SELECT * FROM events.outbox_entries 
WHERE status = 'completed' 
ORDER BY completed_at DESC 
LIMIT 10;

# Check for failed events
SELECT * FROM events.outbox_entries 
WHERE status = 'failed' 
ORDER BY updated_at DESC 
LIMIT 10;
```

#### D. Test API Endpoints
```bash
# Test health endpoint
curl https://api.myhibachi.com/health

# Test authenticated endpoint
curl -H "Authorization: Bearer $TOKEN" \
  https://api.myhibachi.com/api/crm/customers

# Test station admin endpoint
curl -H "Authorization: Bearer $ADMIN_TOKEN" \
  https://api.myhibachi.com/api/admin/stations
```

---

## Potential Risks & Mitigation

### Risk 1: Permission System Broken
**Symptom**: Users accessing endpoints they shouldn't.
**Check**: Test each permission level after deployment.
**Rollback**: Revert `station_middleware.py` and `station_admin.py` changes.

### Risk 2: Workers Not Processing Events
**Symptom**: SMS/emails not sending, Stripe payments not processing.
**Check**: Query outbox_entries table for pending events.
**Fix**: Verify worker configs in environment, check logs for errors.

### Risk 3: Audit Logging Not Working
**Symptom**: No entries in station_activity_logs table.
**Check**: Test station admin actions, verify DB writes.
**Fix**: Verify AsyncSession usage, check audit_log_action calls.

### Risk 4: Async Session Issues
**Symptom**: Database errors in station_admin endpoints.
**Check**: Test all CRUD operations on stations.
**Fix**: Verify all queries use `await` and AsyncSession methods.

---

## Rollback Plan

If critical issues found:

1. **OpenAPI Still Broken**: 
   - Revert all `default_factory` changes
   - Check for remaining callable defaults

2. **Permissions Broken**:
   - Revert `station_middleware.py` 
   - Revert `station_admin.py`

3. **Workers Failing**:
   - Set `WORKERS_ENABLED=false`
   - Investigate outbox_processors.py changes

4. **Full Rollback**:
   ```bash
   git revert <commit-hash>
   # Redeploy previous version
   ```

---

## Success Criteria

✅ OpenAPI JSON endpoint returns 80+ endpoints
✅ Swagger UI loads and displays all endpoints
✅ Station admin endpoints enforce permissions correctly
✅ Audit logging captures all admin actions
✅ Workers process outbox events successfully
✅ No shared mutable default bugs observed
✅ All async database operations work correctly

---

## Contact for Issues

If deployment issues occur:
1. Check application logs: `/var/log/myhibachi/app.log`
2. Check worker logs: `/var/log/myhibachi/workers.log`
3. Check database for pending events: `SELECT * FROM events.outbox_entries WHERE status='pending'`
4. Review Sentry for exceptions (if configured)

**This checklist ensures all changes are production-safe and provides clear testing/monitoring steps.**
